import assert from "node:assert/strict";
import { regexScan, mergeSpans, PATTERN_DESCRIPTIONS } from "../src/lib/regexPatterns.ts";

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (e) {
    failed++;
    console.log(`  ✗ ${name}`);
    console.log(`    ${e.message}`);
  }
}

function hasSource(spans, source) {
  return spans.some((s) => s.source === source);
}

function getSourceSpans(spans, source) {
  return spans.filter((s) => s.source === source);
}

console.log("\n=== regexScan positive cases ===");

test("IBAN: detects valid IBAN", () => {
  const spans = regexScan("My IBAN is GB29NWBK60161331926819");
  assert.ok(hasSource(spans, "iban"), "Should detect IBAN");
  const iban = getSourceSpans(spans, "iban")[0];
  assert.equal(iban.text, "GB29NWBK60161331926819");
});

test("SSN: detects valid SSN", () => {
  const spans = regexScan("SSN: 123-45-6789");
  assert.ok(hasSource(spans, "ssn"), "Should detect SSN");
  const ssn = getSourceSpans(spans, "ssn")[0];
  assert.equal(ssn.text, "123-45-6789");
});

test("MAC: detects valid MAC address", () => {
  const spans = regexScan("MAC: 00:1B:44:11:3A:B7");
  assert.ok(hasSource(spans, "mac"), "Should detect MAC");
  const mac = getSourceSpans(spans, "mac")[0];
  assert.equal(mac.text, "00:1B:44:11:3A:B7");
});

test("IPv4: detects valid IPv4", () => {
  const spans = regexScan("Server: 192.168.1.100");
  assert.ok(hasSource(spans, "ipv4"), "Should detect IPv4");
  const ipv4 = getSourceSpans(spans, "ipv4")[0];
  assert.equal(ipv4.text, "192.168.1.100");
});

test("JWT: detects valid JWT", () => {
  const spans = regexScan("Token: eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U");
  assert.ok(hasSource(spans, "jwt"), "Should detect JWT");
});

test("API Key: detects OpenAI sk- key", () => {
  const spans = regexScan("Key: sk-abcdefghijklmnopqrstuvwxyz1234567890");
  assert.ok(hasSource(spans, "api_key"), "Should detect API key");
});

test("API Key: detects GitHub ghp_ token (40 chars total)", () => {
  const spans = regexScan("Token: ghp_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
  assert.ok(hasSource(spans, "api_key"), "Should detect GitHub token");
});

test("API Key: detects AWS AKIA key", () => {
  const spans = regexScan("AWS: AKIAIOSFODNN7EXAMPLE");
  assert.ok(hasSource(spans, "api_key"), "Should detect AWS key");
});

test("ETH wallet: detects valid Ethereum address", () => {
  const spans = regexScan("ETH: 0x742d35Cc6634C0532925a3b844Bc9e7595f0d12f");
  assert.ok(hasSource(spans, "eth_wallet"), "Should detect ETH wallet");
});

test("BTC wallet: detects bc1 bech32 address", () => {
  const spans = regexScan("BTC: bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4");
  assert.ok(hasSource(spans, "btc_wallet"), "Should detect BTC wallet");
});

test("Bearer token: detects with length bound", () => {
  const spans = regexScan("Authorization: Bearer abcdefghijklmnopqrstuvwxyz1234567890");
  assert.ok(hasSource(spans, "api_key"), "Should detect Bearer token");
});

console.log("\n=== regexScan negative / false-positive cases ===");

test("SSN: rejects 000-00-0000", () => {
  const spans = regexScan("Number: 000-00-0000");
  assert.ok(!hasSource(spans, "ssn"), "Should not flag 000-00-0000");
});

test("SSN: rejects 666-12-3456", () => {
  const spans = regexScan("Number: 666-12-3456");
  assert.ok(!hasSource(spans, "ssn"), "Should not flag 666 prefix");
});

test("ETH wallet: rejects short 0x hex like 0xff", () => {
  const spans = regexScan("Value: 0xff");
  assert.ok(!hasSource(spans, "eth_wallet"), "Should not flag short hex");
});

test("ETH wallet: rejects 0x000...0 zero address", () => {
  const spans = regexScan("Zero: 0x0000000000000000000000000000000000000000");
  assert.ok(!hasSource(spans, "eth_wallet"), "Should not flag zero address");
});

test("BTC wallet: rejects 1 followed by all zeros", () => {
  const spans = regexScan("Bad: 1000000000000000000000000000000000");
  assert.ok(!hasSource(spans, "btc_wallet"), "Should not flag all-zero BTC");
});

test("SOL wallet: pattern removed from PATTERNS (too broad without checksum)", () => {
  const spans = regexScan("Random ID: 7EcDhSYGxXyscszYEp35KHN8vvw3svAuLKTzXwCFLtV");
  assert.ok(!hasSource(spans, "sol_wallet"), "sol_wallet should not be in PATTERNS");
});

test("API Key: Bearer does not match very long prose", () => {
  const longProse = "Bearer " + "a".repeat(600);
  const spans = regexScan(longProse);
  const apiSpans = getSourceSpans(spans, "api_key");
  for (const s of apiSpans) {
    assert.ok(s.text.length <= 520, `Bearer match too long: ${s.text.length}`);
  }
});

test("IPv4: rejects 256.1.1.1", () => {
  const spans = regexScan("IP: 256.1.1.1");
  assert.ok(!hasSource(spans, "ipv4"), "Should not flag 256.x.x.x");
});

console.log("\n=== mergeSpans ===");

test("mergeSpans: non-overlapping spans kept as-is", () => {
  const src = "abc       xyz";
  const a = [{ label: "secret", text: "abc", start: 0, end: 3, source: "model" }];
  const b = [{ label: "secret", text: "xyz", start: 10, end: 13, source: "regex" }];
  const merged = mergeSpans(a, b, src);
  assert.equal(merged.length, 2);
});

test("mergeSpans: fully overlapping span skipped", () => {
  const src = "abcdef";
  const a = [{ label: "secret", text: "abcdef", start: 0, end: 6, source: "model" }];
  const b = [{ label: "secret", text: "cde", start: 2, end: 5, source: "regex" }];
  const merged = mergeSpans(a, b, src);
  assert.equal(merged.length, 1);
  assert.equal(merged[0].text, "abcdef");
});

test("mergeSpans: small overlap extends prior span instead of truncating", () => {
  const src = "Doe X Smith Jr";
  const a = [{ label: "secret", text: "Doe X Smith", start: 0, end: 11, source: "model" }];
  const b = [{ label: "secret", text: "Smith Jr", start: 7, end: 15, source: "regex" }];
  const merged = mergeSpans(a, b, src);
  assert.equal(merged.length, 1);
  assert.equal(merged[0].start, 0);
  assert.equal(merged[0].end, 15);
  assert.equal(merged[0].text, "Doe X Smith Jr");
});

test("mergeSpans: large overlap skips new span entirely", () => {
  const src = "abcdefghij";
  const a = [{ label: "secret", text: "abcdefghij", start: 0, end: 10, source: "model" }];
  const b = [{ label: "secret", text: "cdefgh", start: 2, end: 8, source: "regex" }];
  const merged = mergeSpans(a, b, src);
  assert.equal(merged.length, 1);
  assert.equal(merged[0].text, "abcdefghij");
});

test("mergeSpans: empty inputs return empty", () => {
  assert.deepEqual(mergeSpans([], [], ""), []);
});

console.log("\n=== PATTERN_DESCRIPTIONS ===");

test("PATTERN_DESCRIPTIONS has entries for all regex sources in PATTERNS", () => {
  const scanResult = regexScan("GB29NWBK60161331926819 123-45-6789 00:1B:44:11:3A:B7 192.168.1.1");
  for (const span of scanResult) {
    assert.ok(PATTERN_DESCRIPTIONS[span.source], `Missing description for ${span.source}`);
  }
});

test("sol_wallet is NOT in PATTERN_DESCRIPTIONS (removed due to high FP rate)", () => {
  assert.ok(!PATTERN_DESCRIPTIONS["sol_wallet"], "sol_wallet should not be in descriptions");
});

console.log(`\n${passed} passed, ${failed} failed\n`);
process.exit(failed > 0 ? 1 : 0);
