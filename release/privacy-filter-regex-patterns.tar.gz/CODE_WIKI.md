# Privacy Filter — Code Wiki

## 1. 项目概览

**Privacy Filter** 是一个完全在浏览器本地运行的 PII（个人身份信息）检测与脱敏工具。用户粘贴文本或上传图片后，系统会自动识别其中的姓名、邮箱、电话、地址、账号、日期、URL 和密钥等敏感信息，并提供标注视图和脱敏文本。

核心设计原则：**零上传、零追踪、100% 本地推理**。

- 在线地址：`https://privacyfilter.app`
- 模型：[`openai/privacy-filter`](https://huggingface.co/openai/privacy-filter)（公开权重，BIOES 标签的 Token 分类模型）
- 推理引擎：[Transformers.js](https://huggingface.co/docs/transformers.js)（WebGPU 优先，WASM 回退）
- OCR：[Tesseract.js v7](https://github.com/naptha/tesseract.js)（浏览器端光学字符识别）

---

## 2. 技术栈

| 层级 | 技术 | 版本 |
|------|------|------|
| SSG 框架 | Astro | ^5.13.5 |
| CSS | Tailwind CSS (v4) + @tailwindcss/vite | ^4.2.4 |
| ML 推理 | @huggingface/transformers | ^4.2.0 |
| OCR | tesseract.js | ^7.0.0 |
| 运行时 | TypeScript | ^5.6.3 |
| 部署 | Cloudflare Workers (wrangler) | ^4.0.0 |
| 包管理 | pnpm | >=9 |

---

## 3. 项目结构

```
privacyfilter.app/
├── .github/
│   ├── workflows/ci.yml            # CI：pnpm install → pnpm build
│   └── ISSUE_TEMPLATE/             # Bug / Feature 模板
├── src/
│   ├── worker.ts                   # Cloudflare Worker：HF 代理 + COOP/COEP
│   ├── content.config.ts           # Astro Content Collections 定义
│   ├── components/
│   │   └── BlogLanguageSwitcher.astro  # 博客语言切换下拉
│   ├── content/blog/               # 多语言博客 Markdown
│   │   ├── en/                     # 英文文章
│   │   ├── ja/                     # 日文文章
│   │   ├── zh-CN/                  # 简体中文文章
│   │   └── ...                     # 其他 8 种语言
│   ├── lib/
│   │   ├── i18n.js                 # 国际化字符串 + Demo 数据
│   │   ├── blog.ts                 # 博客内容查询与路由
│   │   └── regexPatterns.ts        # 手工维护的正则模式（新增）
│   ├── pages/
│   │   ├── [...locale].astro       # 主页面（文本检测 + 图片 OCR）
│   │   ├── 404.astro               # 404 页面
│   │   ├── blog/
│   │   │   ├── index.astro         # 博客列表页（英文）
│   │   │   └── [slug].astro        # 博客文章详情页（英文）
│   │   └── [lang]/blog/
│   │       ├── index.astro         # 博客列表页（多语言）
│   │       └── [slug].astro        # 博客文章详情页（多语言）
│   └── styles/
│       └── global.css              # 全局样式 + Tailwind 主题变量
├── astro.config.mjs                # Astro 配置（Tailwind 插件 + COOP/COEP）
├── wrangler.jsonc                  # Cloudflare Workers 部署配置
├── tsconfig.json                   # TypeScript 严格模式
├── package.json                    # 依赖与脚本
├── pnpm-lock.yaml                  # 锁文件
└── .env.example                    # 环境变量模板
```

---

## 4. 架构详解

### 4.1 整体架构图

```
┌─────────────────────────────────────────────────────────────┐
│                     Cloudflare Workers                       │
│  ┌──────────────────┐  ┌────────────────────────────────┐   │
│  │  /hf/* 请求       │  │  其他请求 → ASSETS (Astro SSG) │   │
│  │  → 代理 HF CDN   │  │  + COOP/COEP 安全头            │   │
│  └──────────────────┘  └────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    浏览器端 (Client-Side)                     │
│                                                              │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │  文本输入      │    │  图片输入      │    │  正则预扫描   │  │
│  │  (textarea)   │    │  (canvas)     │    │  (regexPatterns)│
│  └──────┬───────┘    └──────┬───────┘    └──────┬───────┘  │
│         │                    │                    │          │
│         │           ┌────────▼────────┐          │          │
│         │           │  Tesseract.js   │          │          │
│         │           │  (本地 OCR)      │          │          │
│         │           └────────┬────────┘          │          │
│         │                    │                    │          │
│         ▼                    ▼                    ▼          │
│  ┌──────────────────────────────────────────────────────┐   │
│  │          Transformers.js Pipeline                     │   │
│  │   model: openai/privacy-filter                        │   │
│  │   task: token-classification                          │   │
│  │   device: WebGPU (优先) / WASM (回退)                  │   │
│  └──────────────────────┬───────────────────────────────┘   │
│                         │                                    │
│                         ▼                                    │
│  ┌──────────────────────────────────────────────────────┐   │
│  │            Span 合并 + 正则补充                        │   │
│  │  → 标注视图 (annotated)                               │   │
│  │  → 脱敏文本 (redacted)                                │   │
│  │  → 图片遮罩 (canvas masks)                            │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

### 4.2 数据流

1. **文本检测流程**：
   - 用户输入文本 → `runDetection()` → `classifier(text, { aggregation_strategy: "simple" })` → 原始 spans → `normalizeSpan()` 规范化 → `redact()` 生成脱敏文本 / `renderAnnotatedResult()` 渲染标注

2. **图片检测流程**：
   - 用户上传/选择图片 → `runImageDetection()` → Tesseract.js OCR → `collectOcrWords()` + `buildTextFromOcrWords()` → 同上文本检测流程 → `renderImageOverlays()` 在 Canvas 上绘制遮罩

3. **正则补充流程**（新增）：
   - 文本输入 → `regexScan()` 预扫描 → 产生确定性模式 spans → 与模型 spans 合并去重 → 最终结果

---

## 5. 模块职责

### 5.1 `src/worker.ts` — Cloudflare Worker

| 函数/常量 | 职责 |
|-----------|------|
| `proxyHuggingFace(request, url)` | 代理 `/hf/*` 请求到 Hugging Face CDN，添加 CORS 头，实现 Cache API 缓存 |
| `withCrossOriginIsolation(response)` | 为所有响应添加 `Cross-Origin-Opener-Policy: same-origin` 和 `Cross-Origin-Embedder-Policy: require-corp` |
| `export default { fetch() }` | 请求路由：`/hf/*` → 代理；其他 → 静态资源 + COOP/COEP |

**为什么需要 HF 代理？** 浏览器加载 Transformers.js 模型时需要从 Hugging Face 下载 ONNX 权重。由于 COOP/COEP 要求，直接跨域请求会被阻止，因此通过同域代理转发。

### 5.2 `src/pages/[...locale].astro` — 主页面

这是项目的核心页面，包含完整的检测 UI 和客户端逻辑。

#### 服务端（Astro SSG）

- `getStaticPaths()` 生成 11 个语言版本的静态页面
- 从 `i18n.js` 读取翻译字符串和 SEO 元数据
- 渲染完整的 HTML 结构：header、输入区、输出区、图片区、信任保证、工作原理、实体类型、用例、FAQ、footer

#### 客户端（`<script>` 块）

核心变量和函数：

| 变量/函数 | 职责 |
|-----------|------|
| `classifier` | Transformers.js pipeline 实例（懒加载） |
| `ocrWorker` | Tesseract.js worker 实例（懒加载） |
| `loadModel()` | 加载 `openai/privacy-filter` 模型，优先 WebGPU |
| `loadOcrWorker()` | 初始化 Tesseract.js OCR worker |
| `runDetection()` | 执行文本 PII 检测主流程 |
| `runImageDetection()` | 执行图片 OCR + PII 检测流程 |
| `normalizeSpan(span, source, searchFrom)` | 将模型输出的 span 规范化（处理 `##` 前缀、位置偏移） |
| `redact(source, spans)` | 根据 spans 生成脱敏文本，替换为 `[LABEL]` |
| `renderAnnotatedResult()` | 渲染带颜色标注的原文 |
| `renderImageOverlays(text, spans, words)` | 将 PII spans 映射回 OCR 单词坐标，在 Canvas 上绘制遮罩 |
| `collectOcrWords(blocks)` | 从 Tesseract 输出中提取单词及其 bbox |
| `buildTextFromOcrWords(ocrWords)` | 将 OCR 单词拼接为文本，记录每个单词的 start/end 位置 |
| `scheduleDetection(delay)` | 防抖调度自动检测 |
| `createMask(box, source)` | 创建图片遮罩对象 |
| `drawImageCanvas()` | 重绘 Canvas（图片 + 遮罩 + 选中态） |

### 5.3 `src/lib/i18n.js` — 国际化

| 导出 | 职责 |
|------|------|
| `localeNames` | 语言列表（locale、路径、显示名） |
| `routeToLocale` | URL 路径段 → locale 映射 |
| `localeToHtmlLang` | locale → HTML lang 属性映射 |
| `localeToOgLocale` | locale → OG locale 映射 |
| `localeIsRtl` | locale → RTL 标记 |
| `seo` | 各语言 SEO 元数据（标题、描述） |
| `i18n` | 各语言完整 UI 字符串（含 `labels` 实体标签映射） |
| `demos` | 各语言示例文本数据 |
| `defaultDemoIdFor(locale)` | 获取指定语言的默认 demo ID |

### 5.4 `src/lib/blog.ts` — 博客内容管理

| 导出 | 职责 |
|------|------|
| `BlogLocale` | 博客支持的语言类型 |
| `postLocale(post)` | 从文章 ID 推断语言 |
| `postSlug(post)` | 提取文章 slug |
| `blogIndexPath(locale)` | 博客列表页路径 |
| `blogPostPath(locale, slug)` | 文章详情页路径 |
| `getPostsForLocale(locale)` | 按语言获取已发布文章（按日期倒序） |
| `getAllAlternates(slug)` | 获取某文章的所有语言替代链接 |
| `formatPostDate(date, locale)` | 按语言格式化日期 |

### 5.5 `src/lib/regexPatterns.ts` — 正则模式（新增）

手工维护的确定性正则模式，用于补充模型在结构化格式上的不足。详见第 7 节。

### 5.6 `src/content.config.ts` — 内容集合

定义 `blog` 集合：使用 glob loader 扫描 `src/content/blog/**/*.md`，schema 包含 title、description、pubDate、updatedDate、author、tags、draft。

### 5.7 `src/components/BlogLanguageSwitcher.astro` — 语言切换

接收 `currentLocale`、`options`、`menuLabel` 属性，渲染 `<details>` 下拉菜单。

### 5.8 `src/styles/global.css` — 全局样式

- Tailwind CSS v4 导入
- 自定义主题变量：`--color-bg`、`--color-panel`、`--color-text`、`--color-muted`、`--color-line`、`--color-accent`、`--color-accent-dark`、`--color-good`、`--color-warn`、`--color-bad`
- 状态指示点样式（idle / loading / ready / error）
- Demo 按钮样式
- 实体标注芯片样式（8 种颜色对应 8 种实体类型）
- 图片框架棋盘格背景

---

## 6. 支持的实体类型

| 标签 | 英文名 | 中文说明 | 颜色 |
|------|--------|----------|------|
| `private_person` | Name | 姓名、个人标识 | 紫色 |
| `private_email` | Email | 个人邮箱 | 橙色 |
| `private_phone` | Phone | 个人电话 | 青色 |
| `private_address` | Address | 居住/邮寄地址 | 黄色 |
| `account_number` | Account number | 金融/服务账号 | 绿色 |
| `private_date` | Date | 个人相关日期 | 灰色 |
| `private_url` | URL | 个人 URL | 蓝色 |
| `secret` | Secret | 凭据、令牌、API Key | 粉色 |

---

## 7. 正则模式补充（regexPatterns.ts）

### 设计理念

模型的强项在于**上下文理解**——识别自由文本中的姓名、地址等需要语义判断的实体。但对于结构化的确定性格式（如 IBAN、SSN、MAC 地址），正则表达式具有零误判、零漏判的优势。

**分工原则**：确定性模式交给正则，模糊判断留给模型。

### 新增的正则模式

| 模式 | 标签 | 说明 |
|------|------|------|
| IBAN | `account_number` | 国际银行账号（含国家代码校验） |
| SSN | `secret` | 美国社会安全号（AAA-GG-SSSS） |
| MAC 地址 | `secret` | 网络设备物理地址 |
| IPv4 | `secret` | 互联网协议地址 v4 |
| IPv6 | `secret` | 互联网协议地址 v6 |
| JWT | `secret` | JSON Web Token（三段式 Base64URL） |
| API Key | `secret` | 常见 API Key 前缀模式 |
| 加密钱包地址 | `secret` | BTC / ETH / 其他链地址 |

### API

```typescript
interface RegexSpan {
  label: string;
  text: string;
  start: number;
  end: number;
  source: string;
}

function regexScan(text: string): RegexSpan[]
function mergeSpans(modelSpans: RegexSpan[], regexSpans: RegexSpan[]): RegexSpan[]
```

---

## 8. 依赖关系图

```
[...locale].astro
  ├── i18n.js (翻译、Demo 数据)
  ├── global.css (样式)
  ├── @huggingface/transformers (ML 推理)
  ├── tesseract.js (OCR)
  └── regexPatterns.ts (正则补充) ← 新增

blog/[slug].astro, blog/index.astro
  ├── i18n.js
  ├── blog.ts (内容查询)
  ├── global.css
  └── BlogLanguageSwitcher.astro

worker.ts (Cloudflare Worker)
  └── 无外部依赖（仅 Fetch API + Cache API）

content.config.ts
  └── astro:content (Astro 内置)
```

---

## 9. 运行与部署

### 本地开发

```bash
# 安装依赖
pnpm install

# 启动开发服务器
pnpm dev

# 类型检查
pnpm check

# 构建生产版本
pnpm build

# 本地预览构建结果
pnpm preview
```

### 部署到 Cloudflare

```bash
# 构建并部署
pnpm deploy
# 等价于: pnpm build && wrangler deploy
```

### 环境变量

| 变量 | 说明 | 必需 |
|------|------|------|
| `PUBLIC_ANALYTICS_DOMAIN` | 分析脚本域名 | 否 |
| `PUBLIC_ANALYTICS_SRC` | 分析脚本 URL | 否 |

### CI

GitHub Actions（`.github/workflows/ci.yml`）：push/PR 到 main 时自动执行 `pnpm install --frozen-lockfile && pnpm build`。

---

## 10. 关键设计决策

### 10.1 为什么用 Cloudflare Workers 代理 Hugging Face？

浏览器启用 `Cross-Origin-Opener-Policy: same-origin` + `Cross-Origin-Embedder-Policy: require-corp` 后，跨域请求需要 CORP/CORS 头。Hugging Face CDN 默认不带这些头，因此通过同域 Worker 代理添加。

### 10.2 为什么模型推理在客户端？

隐私承诺：用户文本不离开设备。Transformers.js 支持 WebGPU 加速和 WASM 回退，使浏览器端推理成为可能。

### 10.3 为什么用 Tesseract.js 而非服务端 OCR？

同样的隐私原则——OCR 在浏览器本地执行，图片不上传到服务器。

### 10.4 为什么需要正则补充？

`openai/privacy-filter` 模型基于上下文进行 Token 分类，对结构化格式（IBAN、MAC 地址等）的识别不稳定。正则表达式对这些确定性模式有 100% 的准确率，两者互补。

### 10.5 WebGPU vs WASM 设备选择

- 移动设备（`pointer: coarse`、低内存、Mobile UA）→ 强制 WASM，单线程
- 桌面设备 → 优先 WebGPU，最多 4 线程

---

## 11. 国际化

支持 11 种语言，RTL 布局自动适配阿拉伯语：

| Locale | 路径 | 方向 |
|--------|------|------|
| en | `/` | LTR |
| ja | `/ja` | LTR |
| zh-CN | `/zh-hans` | LTR |
| zh-TW | `/zh-hant` | LTR |
| es | `/es` | LTR |
| de | `/de` | LTR |
| fr | `/fr` | LTR |
| ru | `/ru` | LTR |
| pt-BR | `/pt-br` | LTR |
| ar | `/ar` | RTL |
| ko | `/ko` | LTR |

---

## 12. 安全与隐私

- **零上传**：所有推理在浏览器本地完成
- **COOP/COEP**：防止 Spectre 类侧信道攻击
- **模型缓存**：使用浏览器 Cache API，避免重复下载
- **无追踪**：不设 Cookie，不收集用户数据（分析脚本为可选配置）
